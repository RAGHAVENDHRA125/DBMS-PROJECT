class Book:
    def __init__(self, title, author, description, genres, avg_rating, num_ratings, url):
        self.title = title
        self.author = author
        self.description = description
        self.genres = genres
        self.avg_rating = avg_rating
        self.num_ratings = num_ratings
        self.url = url
